from __future__ import annotations

import json
import math
import os
import re
import subprocess
from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

SNAPSHOT_TOKEN_LIMIT = 1000
SCHEMA_TOKEN_LIMIT = 200
TOOL_VERSION = "kbgen@0.1"

SCHEMA_TEXT = """Keys:
m = modules
r = role / responsibility
e = exports
d = depends_on
u = used_by
i = invariant / expectation
f = directional flow (mostly acyclic)
no = negative knowledge (discourage paths)
h = decision hints
ls = loop sentinels (bias only)

All entries are heuristic, not authoritative.
Use snapshot to guide WHERE to explore, not to replace reading code.
"""

SUPPORTED_EXTENSIONS = {
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".go",
    ".java",
    ".rb",
    ".rs",
    ".cs",
    ".php",
}

ENTRYPOINT_NAMES = {
    "main.py",
    "app.py",
    "index.js",
    "index.ts",
    "server.js",
    "server.ts",
    "manage.py",
}


def estimate_tokens(text: str) -> int:
    # Approximate token count without external dependencies.
    if not text:
        return 0
    coarse = math.ceil(len(text) / 4)
    punct = len(re.findall(r"[{}\[\](),:\".]", text)) // 4
    return max(1, coarse + punct)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, separators=(",", ":"), ensure_ascii=True) + "\n", encoding="utf-8")


def module_for_path(path: Path, root: Path) -> str:
    rel = path.relative_to(root)
    parts = rel.parts
    if not parts:
        return "root"
    if len(parts) == 1:
        return "root"
    first = parts[0]
    if first.startswith("."):
        return "root"
    return first


def collect_source_files(root: Path) -> list[Path]:
    out: list[Path] = []
    for file in root.rglob("*"):
        if not file.is_file():
            continue
        if any(part in {".git", "node_modules", ".venv", "venv", "dist", "build", ".ai"} for part in file.parts):
            continue
        if file.suffix.lower() in SUPPORTED_EXTENSIONS:
            out.append(file)
    return out


def parse_import_candidates(text: str, suffix: str) -> list[str]:
    candidates: list[str] = []
    if suffix == ".py":
        for m in re.finditer(r"^\s*import\s+([a-zA-Z0-9_\.]+)", text, flags=re.MULTILINE):
            candidates.append(m.group(1).split(".")[0])
        for m in re.finditer(r"^\s*from\s+([a-zA-Z0-9_\.]+)\s+import\s+", text, flags=re.MULTILINE):
            candidates.append(m.group(1).split(".")[0])
    elif suffix in {".js", ".jsx", ".ts", ".tsx"}:
        for m in re.finditer(r"from\s+[\"']([^\"']+)[\"']", text):
            target = m.group(1)
            if target.startswith("."):
                candidates.append(target)
            else:
                candidates.append(target.split("/")[0])
        for m in re.finditer(r"require\([\"']([^\"']+)[\"']\)", text):
            target = m.group(1)
            if target.startswith("."):
                candidates.append(target)
            else:
                candidates.append(target.split("/")[0])
    return candidates


def extract_exports(path: Path, text: str) -> list[str]:
    exports: set[str] = set()
    suffix = path.suffix.lower()
    if suffix == ".py":
        for m in re.finditer(r"^\s*def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(", text, flags=re.MULTILINE):
            exports.add(m.group(1))
        for m in re.finditer(r"^\s*class\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*[:\(]", text, flags=re.MULTILINE):
            exports.add(m.group(1))
    elif suffix in {".js", ".jsx", ".ts", ".tsx"}:
        for m in re.finditer(r"export\s+(?:async\s+)?(?:function|class|const|let|var)\s+([a-zA-Z_][a-zA-Z0-9_]*)", text):
            exports.add(m.group(1))
    return sorted(exports)[:10]


def infer_role(module: str, files: list[Path], has_entrypoint: bool) -> list[str]:
    tags: list[str] = []
    names = {f.name.lower() for f in files}
    joined = " ".join(names)
    if has_entrypoint:
        tags.append("entry")
    if any(k in module.lower() for k in ("api", "route", "http")) or "router" in joined:
        tags.append("routing")
    if any(k in module.lower() for k in ("auth", "login", "session")):
        tags.append("auth")
    if any(k in module.lower() for k in ("db", "repo", "model", "store")):
        tags.append("data")
    if any(k in module.lower() for k in ("service", "svc", "domain", "logic")):
        tags.append("service")
    if any(k in module.lower() for k in ("test", "spec")):
        tags.append("test")
    if not tags:
        tags.append("module")
    return tags[:3]


@dataclass
class ModuleSynthesis:
    role: list[str]
    exports: list[str]
    deps: list[str]
    used_by: list[str]
    invariants: list[str]


@dataclass
class ScanData:
    modules: dict[str, list[Path]]
    deps: dict[str, set[str]]
    entry_modules: set[str]
    exports: dict[str, list[str]]


def structural_scan(root: Path) -> ScanData:
    files = collect_source_files(root)
    modules: dict[str, list[Path]] = defaultdict(list)
    for f in files:
        modules[module_for_path(f, root)].append(f)

    exports: dict[str, list[str]] = defaultdict(list)
    module_names = set(modules.keys())
    deps: dict[str, set[str]] = {m: set() for m in module_names}
    entry_modules: set[str] = set()

    for module, module_files in modules.items():
        exp_names: set[str] = set()
        for file in module_files:
            text = file.read_text(encoding="utf-8", errors="ignore")
            for name in extract_exports(file, text):
                exp_names.add(name)

            if file.name in ENTRYPOINT_NAMES:
                entry_modules.add(module)

            for candidate in parse_import_candidates(text, file.suffix.lower()):
                if candidate in module_names and candidate != module:
                    deps[module].add(candidate)
        exports[module] = sorted(exp_names)[:12]

    return ScanData(modules=dict(modules), deps=deps, entry_modules=entry_modules, exports=exports)


def synthesize(scan: ScanData) -> dict[str, ModuleSynthesis]:
    used_by: dict[str, set[str]] = {m: set() for m in scan.modules}
    for src, targets in scan.deps.items():
        for target in targets:
            used_by[target].add(src)

    out: dict[str, ModuleSynthesis] = {}
    for module, files in scan.modules.items():
        role = infer_role(module, files, module in scan.entry_modules)
        deps = sorted(scan.deps.get(module, set()))
        inv: list[str] = []
        if module in scan.entry_modules:
            inv.append(f"{module}>entry")
        if "test" in role:
            inv.append(f"{module}>no_prod_path")

        out[module] = ModuleSynthesis(
            role=role,
            exports=scan.exports.get(module, []),
            deps=deps,
            used_by=sorted(used_by.get(module, set())),
            invariants=inv,
        )
    return out


def build_snapshot(synth: dict[str, ModuleSynthesis]) -> dict[str, Any]:
    modules: dict[str, Any] = {}
    edges: list[list[str]] = []
    neg: list[str] = []

    for name, item in sorted(synth.items()):
        modules[name] = {
            "r": item.role,
            "e": item.exports[:8],
            "d": item.deps,
            "u": item.used_by,
            "i": item.invariants,
        }
        for dep in item.deps:
            edges.append([name, dep])

        if "data" in item.role and "entry" in item.used_by:
            neg.append(f"{name}<-entry")
        if "auth" in item.role and "entry" in item.role:
            neg.append(f"{name}:split_entry_auth")

    if not edges and modules:
        keys = sorted(modules.keys())
        if len(keys) >= 2:
            edges.append([keys[0], keys[1]])
        else:
            edges.append([keys[0], keys[0]])

    if not neg and modules:
        # Ensure anti-loop signal exists even for sparse repos.
        first = sorted(modules.keys())[0]
        neg.append(f"{first}:avoid_blind_search")

    hints = build_hints(modules)
    ls = [
        "Prefer flow edges before global text search",
        "Validate one module before pivoting paths",
    ]

    snapshot: dict[str, Any] = {
        "m": modules,
        "f": sorted(edges)[:30],
        "no": sorted(set(neg))[:30],
        "h": hints,
        "ls": ls,
    }
    return snapshot


def build_hints(modules: dict[str, Any]) -> dict[str, list[str]]:
    names = sorted(modules.keys())
    if not names:
        return {"bootstrap": ["root"]}

    api_like = [n for n in names if "routing" in modules[n].get("r", [])]
    service_like = [n for n in names if "service" in modules[n].get("r", [])]
    test_like = [n for n in names if "test" in modules[n].get("r", [])]

    hints: dict[str, list[str]] = {}
    hints["add_endpoint"] = (api_like[:1] + service_like[:1] + test_like[:1]) or names[:2]
    if any("auth" in modules[n].get("r", []) for n in names):
        auth = [n for n in names if "auth" in modules[n].get("r", [])]
        hints["auth_change"] = auth[:2]
    else:
        hints["module_change"] = names[:2]
    return hints


def ensure_ai_dir(root: Path) -> Path:
    ai = root / ".ai"
    ai.mkdir(parents=True, exist_ok=True)
    return ai


def enforce_schema_budget(schema_text: str) -> None:
    token_count = estimate_tokens(schema_text)
    if token_count > SCHEMA_TOKEN_LIMIT:
        raise RuntimeError(
            f"schema.kb exceeds token budget: {token_count} > {SCHEMA_TOKEN_LIMIT}"
        )


def evict_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    candidate = json.loads(json.dumps(snapshot))

    def over_budget() -> bool:
        return estimate_tokens(json.dumps(candidate, separators=(",", ":"), ensure_ascii=True)) > SNAPSHOT_TOKEN_LIMIT

    if not over_budget():
        if not candidate.get("f"):
            candidate["f"] = [["root", "root"]]
        if not candidate.get("no"):
            candidate["no"] = ["root:avoid_blind_search"]
        if not candidate.get("h"):
            candidate["h"] = {"bootstrap": ["root"]}
        return candidate

    # 1) flow and negative knowledge
    while over_budget() and candidate.get("f"):
        candidate["f"].pop()
    while over_budget() and candidate.get("no"):
        candidate["no"].pop()

    # 2) decision hints
    while over_budget() and candidate.get("h"):
        longest = max(candidate["h"], key=lambda k: len(candidate["h"][k]))
        if candidate["h"][longest]:
            candidate["h"][longest].pop()
        else:
            candidate["h"].pop(longest, None)

    module_names = sorted(candidate.get("m", {}).keys())

    # 3) invariants
    for m in module_names:
        while over_budget() and candidate["m"].get(m, {}).get("i"):
            candidate["m"][m]["i"].pop()

    # 4) exports
    for m in module_names:
        while over_budget() and candidate["m"].get(m, {}).get("e"):
            candidate["m"][m]["e"].pop()

    # 5) roles
    for m in module_names:
        while over_budget() and candidate["m"].get(m, {}).get("r"):
            candidate["m"][m]["r"].pop()

    if over_budget():
        raise RuntimeError(
            "snapshot.kb exceeds token budget after eviction; reduce repository scope"
        )

    if not candidate.get("f"):
        candidate["f"] = [["root", "root"]]
    if not candidate.get("no"):
        candidate["no"] = ["root:avoid_blind_search"]
    if not candidate.get("h"):
        candidate["h"] = {"bootstrap": ["root"]}

    return candidate


def build_meta(confidence: str, stale_modules: list[str]) -> dict[str, Any]:
    return {
        "generated_at": date.today().isoformat(),
        "tool_version": TOOL_VERSION,
        "coverage": "structure+semantics",
        "confidence": confidence,
        "stale_modules": stale_modules,
    }


def confidence_from_scan(scan: ScanData) -> str:
    if not scan.modules:
        return "low"
    if len(scan.modules) >= 3:
        return "medium"
    return "low"


def init_artifacts(root: Path) -> None:
    ai = ensure_ai_dir(root)
    enforce_schema_budget(SCHEMA_TEXT)

    schema_path = ai / "schema.kb"
    if not schema_path.exists():
        schema_path.write_text(SCHEMA_TEXT, encoding="utf-8")

    meta_path = ai / "meta.json"
    if not meta_path.exists():
        write_json(meta_path, build_meta(confidence="low", stale_modules=[]))


def full_scan(root: Path) -> dict[str, Any]:
    init_artifacts(root)
    scan = structural_scan(root)
    synthesized = synthesize(scan)
    snapshot = build_snapshot(synthesized)
    snapshot = evict_snapshot(snapshot)

    ai = ensure_ai_dir(root)
    write_json(ai / "snapshot.kb", snapshot)
    write_json(ai / "meta.json", build_meta(confidence_from_scan(scan), stale_modules=[]))

    return {
        "modules": len(snapshot.get("m", {})),
        "tokens": estimate_tokens(json.dumps(snapshot, separators=(",", ":"), ensure_ascii=True)),
    }


def _read_snapshot(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _git_changed_files(root: Path) -> list[str]:
    try:
        diff = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            cwd=root,
            check=False,
            capture_output=True,
            text=True,
        )
        changed = {line.strip().replace("\\", "/") for line in diff.stdout.splitlines() if line.strip()}

        untracked = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=root,
            check=False,
            capture_output=True,
            text=True,
        )
        changed.update(
            line.strip().replace("\\", "/") for line in untracked.stdout.splitlines() if line.strip()
        )
        return sorted(changed)
    except FileNotFoundError:
        return []


def incremental_update(root: Path) -> dict[str, Any]:
    init_artifacts(root)
    ai = ensure_ai_dir(root)
    snapshot_path = ai / "snapshot.kb"
    previous = _read_snapshot(snapshot_path)

    scan = structural_scan(root)
    synthesized = synthesize(scan)
    current = build_snapshot(synthesized)

    changed_files = _git_changed_files(root)
    changed_modules = {
        module_for_path(root / f, root)
        for f in changed_files
        if (root / f).suffix.lower() in SUPPORTED_EXTENSIONS
    }

    if not changed_modules:
        # Nothing explicit changed; keep snapshot in sync for newly discovered modules.
        changed_modules = set(current.get("m", {}).keys()) - set(previous.get("m", {}).keys())

    merged = json.loads(json.dumps(previous)) if previous else {"m": {}, "f": [], "no": [], "h": {}, "ls": []}
    merged.setdefault("m", {})

    for module in changed_modules:
        if module in current.get("m", {}):
            merged["m"][module] = current["m"][module]

    existing_modules = set(current.get("m", {}).keys())
    for module in list(merged["m"].keys()):
        if module not in existing_modules:
            merged["m"].pop(module, None)

    # Keep global anti-loop and navigation signals current.
    merged["f"] = current.get("f", [])
    merged["no"] = current.get("no", [])
    merged["h"] = current.get("h", {})
    merged["ls"] = current.get("ls", [])

    merged = evict_snapshot(merged)
    write_json(snapshot_path, merged)

    stale_modules = sorted(set(merged.get("m", {}).keys()) - changed_modules)
    write_json(ai / "meta.json", build_meta(confidence_from_scan(scan), stale_modules=stale_modules))

    return {
        "changed_modules": sorted(changed_modules),
        "modules": len(merged.get("m", {})),
        "tokens": estimate_tokens(json.dumps(merged, separators=(",", ":"), ensure_ascii=True)),
    }
